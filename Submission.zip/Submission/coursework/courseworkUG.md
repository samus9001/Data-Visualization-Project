---
id: litvis

narrative-schemas:
  - ../narrative-schemas/courseworkUG.yml

elm:
  dependencies:
    gicentre/elm-vegalite: latest
    gicentre/tidy: latest
---

@import "../css/datavis.less"

```elm {l=hidden}
import Tidy exposing (..)
import VegaLite exposing (..)
```

# Undergraduate Coursework Template

{(questions|}

- Are there any noticeable characteristics based on statistics from four of the top European football leagues?
- Does applying more pressure lead to more goals scored for the top four teams in each league?
- Should relegated teams in each league play more defensive or offensive to gain more points?

{|questions)}

{(visualization|}

### [RQ1] Identifying characteristics of the top four European football leagues

**_Statistics comparison of each league - Radar Chart_**
![radar chart](/radarchart.png)

### [RQ2] Observing trends between the goals scored by the top four teams in each league

**_Correlation between goals scored and power of pressure for the top four teams in each league - Interactive Line Chart_**

```elm {v interactive}
eplData =
    dataFromUrl "RQ2 EPL.csv"


epllineColours =
    categoricalDomainMap
        [ ( "1", "rgb(59,118,175)" )
        , ( "2", "rgb(255,40,20)" )
        , ( "3", "rgb(81,157,62)" )
        , ( "4", "rgb(239,133,55)" )
        ]


eplencHighlight =
    encoding
        << position X [ pName "Year", pOrdinal, pTitle "Year" ]
        << position Y [ pName "Scored", pQuant ]
        << tooltips
            [ [ tName "Opponent Passes Made In Their Half Avg", tQuant ]
            , [ tName "Scored", tQuant ]
            , [ tName "Position", tQuant ]
            , [ tName "Team", tNominal ]
            , [ tName "Year", tOrdinal, tTitle "Year" ]
            ]
        << color
            [ mSelectionCondition (selectionName "mySelection")
                [ mName "Position", mNominal, mScale epllineColours ]
                [ mStr "black" ]
            ]
        << opacity
            [ mSelectionCondition (selectionName "mySelection")
                [ mNum 1 ]
                [ mNum 0.1 ]
            ]
```

```elm {v interactive}
eplsingleSelection : Spec
eplsingleSelection =
    let
        sel =
            selection
                << select "mySelection" seSingle []
    in
    toVegaLite
        [ width 340
        , height 340
        , eplData [] -- Data specified in code block above
        , eplencHighlight [] -- Encoding specified in code block above
        , line [ maTooltip ttEncoding, maPoint (pmMarker []) ]
        , sel []
        , title "EPL" []
        ]
```

```elm {v interactive}
laligaData =
    dataFromUrl "RQ2 LA LIGA.csv"


laligalineColours =
    categoricalDomainMap
        [ ( "1", "rgb(59,118,175)" )
        , ( "2", "rgb(255,40,20)" )
        , ( "3", "rgb(81,157,62)" )
        , ( "4", "rgb(239,133,55)" )
        ]


laligaencHighlight =
    encoding
        << position X [ pName "Year", pOrdinal, pTitle "Year" ]
        << position Y [ pName "Scored", pQuant ]
        << tooltips
            [ [ tName "Opponent Passes Made In Their Half Avg", tQuant ]
            , [ tName "Scored", tQuant ]
            , [ tName "Position", tQuant ]
            , [ tName "Team", tNominal ]
            , [ tName "Year", tOrdinal, tTitle "Year" ]
            ]
        << color
            [ mSelectionCondition (selectionName "mySelection")
                [ mName "Position", mNominal, mScale laligalineColours ]
                [ mStr "black" ]
            ]
        << opacity
            [ mSelectionCondition (selectionName "mySelection")
                [ mNum 1 ]
                [ mNum 0.1 ]
            ]
```

```elm {v interactive}
laligasingleSelection : Spec
laligasingleSelection =
    let
        sel =
            selection
                << select "mySelection" seSingle []
    in
    toVegaLite
        [ width 340
        , height 340
        , laligaData [] -- Data specified in code block above
        , laligaencHighlight [] -- Encoding specified in code block above
        , line [ maTooltip ttEncoding, maPoint (pmMarker []) ]
        , sel []
        , title "LA LIGA" []
        ]
```

```elm {v interactive}
ligue1Data =
    dataFromUrl "RQ2 LIGUE1.csv"


ligue1lineColours =
    categoricalDomainMap
        [ ( "1", "rgb(59,118,175)" )
        , ( "2", "rgb(255,40,20)" )
        , ( "3", "rgb(81,157,62)" )
        , ( "4", "rgb(239,133,55)" )
        ]


ligue1encHighlight =
    encoding
        << position X [ pName "Year", pOrdinal, pTitle "Year" ]
        << position Y [ pName "Scored", pQuant ]
        << tooltips
            [ [ tName "Opponent Passes Made In Their Half Avg", tQuant ]
            , [ tName "Scored", tQuant ]
            , [ tName "Position", tQuant ]
            , [ tName "Team", tNominal ]
            , [ tName "Year", tOrdinal, tTitle "Year" ]
            ]
        << color
            [ mSelectionCondition (selectionName "mySelection")
                [ mName "Position", mNominal, mScale ligue1lineColours ]
                [ mStr "black" ]
            ]
        << opacity
            [ mSelectionCondition (selectionName "mySelection")
                [ mNum 1 ]
                [ mNum 0.1 ]
            ]
```

```elm {v interactive}
ligue1singleSelection : Spec
ligue1singleSelection =
    let
        sel =
            selection
                << select "mySelection" seSingle []
    in
    toVegaLite
        [ width 340
        , height 340
        , ligue1Data [] -- Data specified in code block above
        , ligue1encHighlight [] -- Encoding specified in code block above
        , line [ maTooltip ttEncoding, maPoint (pmMarker []) ]
        , sel []
        , title "LIGUE 1" []
        ]
```

```elm {v interactive}
serieaData =
    dataFromUrl "RQ2 SERIEA.csv"


seriealineColours =
    categoricalDomainMap
        [ ( "1", "rgb(59,118,175)" )
        , ( "2", "rgb(255,40,20)" )
        , ( "3", "rgb(81,157,62)" )
        , ( "4", "rgb(239,133,55)" )
        ]


serieaencHighlight =
    encoding
        << position X [ pName "Year", pOrdinal, pTitle "Year" ]
        << position Y [ pName "Scored", pQuant ]
        << tooltips
            [ [ tName "Opponent Passes Made In Their Half Avg", tQuant ]
            , [ tName "Scored", tQuant ]
            , [ tName "Position", tQuant ]
            , [ tName "Team", tNominal ]
            , [ tName "Year", tOrdinal, tTitle "Year" ]
            ]
        << color
            [ mSelectionCondition (selectionName "mySelection")
                [ mName "Position", mNominal, mScale seriealineColours ]
                [ mStr "black" ]
            ]
        << opacity
            [ mSelectionCondition (selectionName "mySelection")
                [ mNum 1 ]
                [ mNum 0.1 ]
            ]
```

```elm {v interactive}
serieasingleSelection : Spec
serieasingleSelection =
    let
        sel =
            selection
                << select "mySelection" seSingle []
    in
    toVegaLite
        [ width 340
        , height 340
        , serieaData [] -- Data specified in code block above
        , serieaencHighlight [] -- Encoding specified in code block above
        , line [ maTooltip ttEncoding, maPoint (pmMarker []) ]
        , sel []
        , title "SERIE A" []
        ]
```

### [RQ3] Evaluating the performance of teams that remained due to their play style in each league

**_Comparison of points accumulated by relegated teams in each league - Interactive Bar Chart_**

```elm {v interactive}
eplbarData =
    dataFromUrl "RQ3 EPL.csv"


eplbarColours =
    categoricalDomainMap
        [ ( "17", "rgb(59,118,175)" )
        , ( "18", "rgb(255,40,20)" )
        ]


eplbarencHighlight =
    encoding
        << position X [ pName "Year", pOrdinal ]
        << position Y [ pName "Points", pQuant ]
        << tooltips
            [ [ tName "Passes Made In Own Half Avg", tQuant ]
            , [ tName "Opponent Passes Made In Their Half Avg", tQuant ]
            , [ tName "Passes Made Near Opposition Area", tQuant ]
            , [ tName "Opponent Passes Made Near Own Area", tQuant ]
            , [ tName "Scored", tQuant ]
            , [ tName "Points", tQuant ]
            , [ tName "Team", tNominal ]
            ]
        << color
            [ mSelectionCondition (selectionName "mySelection")
                [ mName "Position", mNominal, mScale eplbarColours ]
                [ mStr "black" ]
            ]
```

```elm {v interactive}
eplbarsingleSelection : Spec
eplbarsingleSelection =
    let
        sel =
            selection
                << select "mySelection" seSingle []
    in
    toVegaLite
        [ width 340
        , height 340
        , eplbarData [] -- Data specified in code block above
        , eplbarencHighlight [] -- Encoding specified in code block above
        , bar []
        , sel []
        , title "EPL" []
        ]
```

```elm {v interactive}
laligabarData =
    dataFromUrl "RQ3 LA LIGA.csv"


laligabarColours =
    categoricalDomainMap
        [ ( "17", "rgb(59,118,175)" )
        , ( "18", "rgb(255,40,20)" )
        ]


laligabarencHighlight =
    encoding
        << position X [ pName "Year", pOrdinal ]
        << position Y [ pName "Points", pQuant ]
        << tooltips
            [ [ tName "Passes Made In Own Half Avg", tQuant ]
            , [ tName "Opponent Passes Made In Their Half Avg", tQuant ]
            , [ tName "Passes Made Near Opposition Area", tQuant ]
            , [ tName "Opponent Passes Made Near Own Area", tQuant ]
            , [ tName "Scored", tQuant ]
            , [ tName "Points", tQuant ]
            , [ tName "Team", tNominal ]
            ]
        << color
            [ mSelectionCondition (selectionName "mySelection")
                [ mName "Position", mNominal, mScale eplbarColours ]
                [ mStr "black" ]
            ]
```

```elm {v interactive}
laligabarsingleSelection : Spec
laligabarsingleSelection =
    let
        sel =
            selection
                << select "mySelection" seSingle []
    in
    toVegaLite
        [ width 340
        , height 340
        , laligabarData [] -- Data specified in code block above
        , laligabarencHighlight [] -- Encoding specified in code block above
        , bar []
        , sel []
        , title "LA LIGA" []
        ]
```

```elm {v interactive}
ligue1barData =
    dataFromUrl "RQ3 LIGUE1.csv"


ligue1barColours =
    categoricalDomainMap
        [ ( "17", "rgb(59,118,175)" )
        , ( "18", "rgb(255,40,20)" )
        ]


ligue1barencHighlight =
    encoding
        << position X [ pName "Year", pOrdinal ]
        << position Y [ pName "Points", pQuant ]
        << tooltips
            [ [ tName "Passes Made In Own Half Avg", tQuant ]
            , [ tName "Opponent Passes Made In Their Half Avg", tQuant ]
            , [ tName "Passes Made Near Opposition Area", tQuant ]
            , [ tName "Opponent Passes Made Near Own Area", tQuant ]
            , [ tName "Scored", tQuant ]
            , [ tName "Points", tQuant ]
            , [ tName "Team", tNominal ]
            ]
        << color
            [ mSelectionCondition (selectionName "mySelection")
                [ mName "Position", mNominal, mScale eplbarColours ]
                [ mStr "black" ]
            ]
```

```elm {v interactive}
ligue1barsingleSelection : Spec
ligue1barsingleSelection =
    let
        sel =
            selection
                << select "mySelection" seSingle []
    in
    toVegaLite
        [ width 340
        , height 340
        , ligue1barData [] -- Data specified in code block above
        , ligue1barencHighlight [] -- Encoding specified in code block above
        , bar []
        , sel []
        , title "LIGUE 1" []
        ]
```

```elm {v interactive}
serieabarData =
    dataFromUrl "RQ3 SERIEA.csv"


serieabarColours =
    categoricalDomainMap
        [ ( "17", "rgb(59,118,175)" )
        , ( "18", "rgb(255,40,20)" )
        ]


serieabarencHighlight =
    encoding
        << position X [ pName "Year", pOrdinal ]
        << position Y [ pName "Points", pQuant ]
        << tooltips
            [ [ tName "Passes Made In Own Half Avg", tQuant ]
            , [ tName "Opponent Passes Made In Their Half Avg", tQuant ]
            , [ tName "Passes Made Near Opposition Area", tQuant ]
            , [ tName "Opponent Passes Made Near Own Area", tQuant ]
            , [ tName "Scored", tQuant ]
            , [ tName "Points", tQuant ]
            , [ tName "Team", tNominal ]
            ]
        << color
            [ mSelectionCondition (selectionName "mySelection")
                [ mName "Position", mNominal, mScale eplbarColours ]
                [ mStr "black" ]
            ]
```

```elm {v interactive}
serieabarsingleSelection : Spec
serieabarsingleSelection =
    let
        sel =
            selection
                << select "mySelection" seSingle []
    in
    toVegaLite
        [ width 340
        , height 340
        , serieabarData [] -- Data specified in code block above
        , serieabarencHighlight [] -- Encoding specified in code block above
        , bar []
        , sel []
        , title "SERIE A" []
        ]
```

{|visualization)}

{(insights|}

My visualizations provided a varied overview of the multiple statistics that can be analyzed in order to gain a greater depth and understanding of the factors that can influence the performance and success of a team as well as an entire league, which has been beneficial in showing the growing significance of statistics in football.

**Visualisation 1:**
**EPL -** I interpreted this league to be the most entertaining to watch due to it either exceeding or being at the top in all statistical comparisons, as well as having the least amount of draws. Therefore, I would presume that the highest quality of football is played in this league making it a priority to follow.

**LA LIGA -** This league is shown to also be of high quality with it having a high amount of points as well as the most goals scored, whilst having the least amount of passes made in the opponents half. Therefore, I would presume that this league has the fairest and entertaining fixtures to watch making it a priority to follow.

**LIGUE 1 -** This league appears to be of low quality due to having the most amount of draws and the least amount of goals scored. This is likely due to the fact that it also has the lowest amount of passes made near the opposition area, which would suggest that goals are more likely to be scored either from defensive mistakes or direct attacks, which don't occur frequently. Therefore, I would presume that this league is the least entertaining to follow due to it providing the lowest quality of football.

**SERIE A -** This league manages to be well rounded by being near the top in each category without being at the top or bottom of any. Therefore, I would presume that the quality of football played is of a good standard although not being well known for anything in particular. It is also amongst the top for the draws category, which would then suggest that this league has the fairest fixtures, making it entertaining to watch as a neutral fan as matches are less likely to be one-sided.

**Visualisation 2:**
From the findings, I interpreted that there were no clear trends to suggest a strong correlation for a team in the top four being able to score more goals as a result of the amount of pressure that they applied to the opposing team. The interactive visualization helped me come to the conclusion that a top team is not guaranteed to score more goals by applying increased pressure in the opponent's half than if they decided to not apply high pressure. Therefore, I believe it is fair to presume that in order for a team to be able to score more goals than usual, several factors would have to be considered and that the team should play to its strengths in order to maximize this, regardless of how much pressure they apply to the opposing team in their half.

**Visualisation 3:**
From the findings, I noticed an interesting trend in both the La Liga and Serie A wherein most seasons the team that was relegated had scored more goals (significantly more in some comparisons) than the team that remained. This would lead me to presume that although the teams that were relegated managed to score enough goals to remain in the league they would suffer from conceding too many goals, therefore in these two leagues a defensive style would be favoured for better results and to gain more points in a season. Whereas the opposite trend can be observed from the EPL and Ligue 1 although the difference between goals scored is much closer, which would suggest that an attacking style is favoured in these leagues to gain more points.

When comparing the possession/pressure statistics between the teams in each league with regards to seeing if they correlated with a defensive or offensive playstyle, I found this to be inconclusive due to there being a lack of a clear trend or correlation with each every comparison as the change in values were mostly marginal.

{|insights)}

{(designJustification|}

I decided to base the design of the visualizations through the use of different charts as they are helpful in providing a distinctive and engaging experience for the user to review and interact with in order to observe patterns and trends, which was the focus of my research questions due to the nature of the dataset being on statistical data of the performance of football teams across different leagues.

**Visualisation 1:**
Although radar charts are not commonly used for most visualizations I wanted to ensure that I used one as they have been commonly used in relation to Football, particularly in the [Pro Evolution Soccer series](pesradarchart.jpg) as well as being effective in showing the distinctiveness of characteristics and performance when used for comparison through statistics (_Biermann, D._). I found radar charts to be unique to look at in comparison to other charts as well as being very useful for comparisons due to the fact that a hexagonal shape allows for not only multiple features to be compared but also for each league to be displayed simultaneously whilst being simple to view as well as the user having to look at either certain sections or multiple charts separately. This also inherently allows the user to easily spot comparisons between features where there may be a significant difference between the statistics of certain leagues in relation to the dataset if present, due to the distance covered by the coloured outlines within the radar shape from the centre to the perimeter. This visualization was exported as an image as vega-lite does not support the encoding of a radar chart therefore, it did not need to be encoded in order to be displayed. However, this also meant that it could not be encoded to be interactive through the use of Tooltip, making it difficult to spot the differences between data points that had small differences.

**Visualisation 2:**
In order for the user to study a visualization to observe for correlations in the data of multiple teams, I decided to use line charts as they are used to convey trends in data through a clear and simple fashion (_Munzner, T._). I encoded the colour of the lines in the chart by using a categorical domain map in order to set them to be strong and have a high contrast from each other in order for them to be clearly differentiated when being viewed (_Stone, M._), as the data was superimposed so that consistencies that formed trends could easily be observed (_Biermann, D._). I also encoded a key for the colours so the user would know what feature each colour represented. As the charts would be reviewed separately I decided against putting them on the same rows to prevent the user from comparing charts from the direct view as this was not the intended purpose based on the research question. I then focused on making the charts interactive by encoding tooltips to allow the user to view additional information about the data lines by hovering over the point markers for a detailed analysis without hindering the overview of the visualization, as well as allowing the user to focus on lines individually by clicking on them to remove the colour from all other lines (_Shneiderman, B_).

**Visualisation 3:**
As the research question focused on comparing the style of play between two teams in each league, I decided it would be most suitable to use bar charts for the visualization in order for the user to easily analyze the differences between the two in each chart as bar charts put an emphasis on discrete comparisons between data points. I encoded the visualization in the same way as the previous visualization but in addition, I encoded the high contrast between the two bars to use specific colours of blue to signify safety for the team that remained, and red to signify danger for the team that was relegated (_Stone, M._).

{|designJustification)}

{(references|}

**Biermann, D.** (2019) Football Hackers: The Science and Art of a Data Revolution. pp. 229-263.

**Munzner, T.** (2015) Visualization Analysis and Design, CRC Press.

**Stone, M.** (2006) Choosing Colors for Data Visualization, _Perceptual Edge_.

**Shneiderman, B.** (1996) The eyes have it: A task by data type taxonomy for information visualization, _Proceedings of the IEEE Symposium on Visual Languages_.

{|references)}
